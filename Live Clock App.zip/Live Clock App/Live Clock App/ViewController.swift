//
//  ViewController.swift
//  Live Clock App
//
//  Created by Emily Denham on 2/2/24.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    @IBOutlet weak var clockLabel: UILabel!
    @IBOutlet weak var backgroundImageView: UIImageView!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var countdownLabel: UILabel!
    @IBOutlet weak var actionButton: UIButton!
    
    var countdownTimer: Timer?
    var totalTime: TimeInterval = 0
    var audioPlayer: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        startClock()
        datePicker.datePickerMode = .countDownTimer
        if #available(iOS 13.4, *) {
            datePicker.preferredDatePickerStyle = .wheels
            datePicker.backgroundColor = UIColor.black
            datePicker.setValue(UIColor.white, forKeyPath: "textColor")
        } else {
            datePicker.backgroundColor = UIColor.black
            datePicker.setValue(UIColor.white, forKeyPath: "textColor")
        }
       
}

    private func startClock() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.updateTime()
        }
    }

    private func updateTime() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E, dd MMM yyyy hh:mm:ss a"
        let currentTime = dateFormatter.string(from: Date())
        clockLabel.text = currentTime

        updateBackgroundImage()
    }

    private func updateBackgroundImage() {
        let hour = Calendar.current.component(.hour, from: Date())
        
        if hour < 12 {
            backgroundImageView.image = UIImage(named: "backgroundAM")
        } else {
            backgroundImageView.image = UIImage(named: "backgroundPM")
        }
    }
    @IBAction func actionButtonTapped(_ sender: UIButton) {
        if countdownTimer == nil {
            // Start Timer
            totalTime = datePicker.countDownDuration
            countdownLabel.text = "Time Remaining: \(formatTime(totalTime))"  // Set initial countdown time
            countdownTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
            actionButton.setTitle("Stop Music", for: .normal)
            datePicker.isEnabled = false
        } else {
            // Stop Music and Timer
            audioPlayer?.stop()
            countdownTimer?.invalidate()
            countdownTimer = nil
            countdownLabel.text = "Time Remaining: 00:00:00"
            actionButton.setTitle("Start Timer", for: .normal)
            datePicker.isEnabled = true
        }
    }

    @objc func updateTimer() {
        if totalTime < 1 {
            // Timer completed
            countdownTimer?.invalidate()
            countdownTimer = nil
            playMusic()
            actionButton.setTitle("Stop Music", for: .normal)
            countdownLabel.text = "Time Remaining: 00:00:00"
        } else {
            // Update countdown
            totalTime -= 1
            countdownLabel.text = "Time Remaining: \(formatTime(totalTime))"
        }
    }

    func formatTime(_ totalSeconds: TimeInterval) -> String {
        let hours = Int(totalSeconds) / 3600
        let minutes = Int(totalSeconds) % 3600 / 60
        let seconds = Int(totalSeconds) % 3600 % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }

    func playMusic() {
        guard let url = Bundle.main.url(forResource: "Aves - Going Somewhere", withExtension: "mp3") else {
            print("Music file not found.")
            return
        }
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch let error {
            print("Error playing music: \(error.localizedDescription)")
        }
    }
    

}
